(function(){
Template.body.addContent((function() {
  var view = this;
  return HTML.DIV({
    "class": "container"
  }, "\n    ", Spacebars.include(view.lookupTemplate("hello")), "\n");
}));
Meteor.startup(Template.body.renderToDocument);

Template.__checkName("hello");
Template["hello"] = new Template("Template.hello", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col-md-4 push-down"
  }, "\n        ", HTML.DIV({
    "class": "panel panel-default"
  }, "\n            ", HTML.Raw('<div class="panel-heading">\n                <h3 class="panel-title">Uploads section</h3>\n            </div>'), "\n            ", HTML.Raw('<div class="panel-body">\n                <p>\n                    Add Files\n          <span class="btn btn-default btn-file">\n            <input multiple="" class="file fileInput" type="file">\n          </span>\n                </p>\n            </div>'), "\n            ", HTML.TABLE({
    "class": "table table-hover table-stripped table-bordered"
  }, "\n                ", HTML.THEAD("\n                ", HTML.TH("Name"), "\n                ", HTML.TH("Download"), "\n                "), "\n                ", HTML.TBODY("\n                ", Blaze.Each(function() {
    return Spacebars.call(view.lookup("uploads"));
  }, function() {
    return [ "\n                    ", HTML.TR("\n                        ", HTML.TD(Blaze.View("lookup:name", function() {
      return Spacebars.mustache(view.lookup("name"));
    })), "\n                        ", HTML.TD("\n                            ", HTML.A({
      "class": "btn btn-primary",
      href: function() {
        return Spacebars.mustache(view.lookup("url"), Spacebars.kw({
          download: true
        }));
      }
    }, "Download"), "\n                        "), "\n                    "), "\n                " ];
  }), "\n                "), "\n            "), "\n\n        "), "\n    ");
}));

})();
